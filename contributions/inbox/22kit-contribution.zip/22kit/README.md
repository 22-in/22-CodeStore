# 22Kit
**A lightweight, dependency-free Python utility toolkit by 22.**

22Kit provides small helpers for human-readable sizes, duration formatting, slug
generation, JSON handling, directory creation, and retrying transient failures.

- Python 3.8+
- Standard library only; no runtime dependencies
- Cross-platform
- No network access, telemetry, or shell execution
- MIT license

## Modules
- `22kit.formatting`: `human_size`, `format_time`, `slugify`
- `22kit.json`: `safe_json_loads`, `safe_json_dumps`, `load_json`, `save_json`
- `22kit.filesystem`: `ensure_dir`
- `22kit.retry`: `retry`

The import package is named `22kit`. Because Python identifiers cannot begin
with a digit, import it dynamically with `importlib.import_module("22kit")`.
See `examples/` and `tests/`.

`22-manifest.json` is proposed 22 Code Store metadata. Align its field names with
the Store's actual schema if required; that schema was not provided here.
