import importlib
import json
import tempfile
import unittest
from pathlib import Path

kit = importlib.import_module("22kit")

class KitTests(unittest.TestCase):
    def test_formatting(self):
        self.assertEqual(kit.human_size(0), "0 B")
        self.assertEqual(kit.human_size(1024), "1.00 KiB")
        self.assertEqual(kit.human_size(1000, binary=False), "1.00 KB")
        self.assertEqual(kit.format_time(12.5), "12.50s")
        self.assertEqual(kit.format_time(3661), "1h 1m 1s")
        self.assertEqual(kit.slugify("Hello, World!"), "hello-world")
    def test_validation(self):
        with self.assertRaises(ValueError): kit.human_size(-1)
        with self.assertRaises(TypeError): kit.human_size(True)
        with self.assertRaises(ValueError): kit.format_time(-1)
    def test_json(self):
        self.assertEqual(kit.safe_json_loads('{"x":1}'), {"x": 1})
        self.assertIsNone(kit.safe_json_loads("{bad"))
        with self.assertRaises(json.JSONDecodeError): kit.safe_json_loads("{bad", strict=True)
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "nested" / "data.json"
            kit.save_json(target, {"ok": True})
            self.assertEqual(kit.load_json(target), {"ok": True})
            self.assertIsNone(kit.load_json(Path(tmp) / "missing.json"))
    def test_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "a" / "b"
            self.assertEqual(kit.ensure_dir(target), target)
            self.assertTrue(target.is_dir())
    def test_retry(self):
        state = {"n": 0}
        @kit.retry(attempts=3, exceptions=ValueError)
        def eventually():
            state["n"] += 1
            if state["n"] < 3: raise ValueError("transient")
            return "ok"
        self.assertEqual(eventually(), "ok")
        self.assertEqual(state["n"], 3)
        @kit.retry(attempts=2, exceptions=ValueError)
        def fail(): raise ValueError("final")
        with self.assertRaises(ValueError): fail()

if __name__ == "__main__":
    unittest.main()
