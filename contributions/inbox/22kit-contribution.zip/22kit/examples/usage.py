from importlib import import_module
kit = import_module("22kit")

print(kit.human_size(1536000))
print(kit.format_time(3723))
print(kit.slugify("22Kit: A Python Toolkit"))

folder = kit.ensure_dir("demo-data")
kit.save_json(folder / "config.json", {"theme": "dark", "version": 1})
print(kit.load_json(folder / "config.json"))

@kit.retry(attempts=3, delay=0.1, backoff=2, exceptions=(TimeoutError,))
def connect():
    return "connected"

print(connect())
