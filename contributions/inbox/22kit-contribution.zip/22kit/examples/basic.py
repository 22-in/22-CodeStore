from importlib import import_module
kit = import_module("22kit")
print(kit.human_size(1024))
print(kit.format_time(3661))
print(kit.slugify("Hello, 22Kit!"))
