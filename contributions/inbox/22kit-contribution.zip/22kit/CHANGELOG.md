# Changelog
## 1.0.0 - 2026-11-08
- Initial release: formatting, JSON, filesystem, and retry helpers.
- Standard-library-only runtime; Python 3.8+.
