import time
from functools import wraps

def retry(*, attempts=3, delay=0.0, backoff=1.0, exceptions=(Exception,), on_retry=None):
    if isinstance(attempts, bool) or not isinstance(attempts, int) or attempts < 1:
        raise ValueError("attempts must be an integer >= 1")
    if isinstance(delay, bool) or not isinstance(delay, (int, float)) or delay < 0:
        raise ValueError("delay must be a non-negative number")
    if isinstance(backoff, bool) or not isinstance(backoff, (int, float)) or backoff < 1:
        raise ValueError("backoff must be a number >= 1")
    if isinstance(exceptions, type) and issubclass(exceptions, BaseException):
        exceptions = (exceptions,)
    if not isinstance(exceptions, tuple) or not exceptions or not all(
        isinstance(e, type) and issubclass(e, BaseException) for e in exceptions
    ):
        raise TypeError("exceptions must be an exception class or non-empty tuple of exception classes")
    if on_retry is not None and not callable(on_retry):
        raise TypeError("on_retry must be callable or None")
    def decorator(function):
        @wraps(function)
        def wrapper(*args, **kwargs):
            wait = float(delay)
            for attempt in range(1, attempts + 1):
                try:
                    return function(*args, **kwargs)
                except exceptions as error:
                    if attempt == attempts: raise
                    if on_retry is not None: on_retry(error, attempt, wait)
                    if wait: time.sleep(wait)
                    wait *= backoff
        return wrapper
    return decorator
