from pathlib import Path

def ensure_dir(path, *, parents=True, exist_ok=True):
    directory = Path(path)
    directory.mkdir(parents=parents, exist_ok=exist_ok)
    return directory
