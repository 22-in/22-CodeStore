import json
from pathlib import Path

def safe_json_loads(data, *, default=None, strict=False):
    if not isinstance(data, (str, bytes, bytearray)):
        raise TypeError("data must be str, bytes, or bytearray")
    try:
        return json.loads(data)
    except (json.JSONDecodeError, UnicodeDecodeError):
        if strict: raise
        return default

def safe_json_dumps(data, *, indent=2, sort_keys=False, ensure_ascii=False):
    return json.dumps(data, indent=indent, sort_keys=sort_keys, ensure_ascii=ensure_ascii)

def load_json(path, *, default=None, strict=False, encoding="utf-8"):
    try:
        with Path(path).open("r", encoding=encoding) as stream:
            return json.load(stream)
    except (OSError, json.JSONDecodeError, UnicodeDecodeError):
        if strict: raise
        return default

def save_json(path, data, *, indent=2, sort_keys=False, ensure_ascii=False,
              encoding="utf-8", create_parents=True):
    destination = Path(path)
    if create_parents:
        destination.parent.mkdir(parents=True, exist_ok=True)
    payload = safe_json_dumps(data, indent=indent, sort_keys=sort_keys, ensure_ascii=ensure_ascii)
    temporary = destination.with_name(destination.name + ".22kit-tmp")
    try:
        with temporary.open("w", encoding=encoding) as stream:
            stream.write(payload + "\n")
        temporary.replace(destination)
    except Exception:
        try: temporary.unlink()
        except OSError: pass
        raise
    return destination
