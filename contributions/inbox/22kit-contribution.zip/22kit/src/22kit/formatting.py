import re
import unicodedata

def human_size(size, *, decimal_places=2, binary=True):
    if isinstance(size, bool) or not isinstance(size, (int, float)):
        raise TypeError("size must be an int or float")
    if size < 0:
        raise ValueError("size must be non-negative")
    if isinstance(decimal_places, bool) or not isinstance(decimal_places, int):
        raise TypeError("decimal_places must be an integer")
    if not 0 <= decimal_places <= 10:
        raise ValueError("decimal_places must be between 0 and 10")
    base = 1024.0 if binary else 1000.0
    units = ("B", "KiB", "MiB", "GiB", "TiB", "PiB") if binary else ("B", "KB", "MB", "GB", "TB", "PB")
    value, index = float(size), 0
    while value >= base and index < len(units) - 1:
        value /= base
        index += 1
    if index == 0:
        return "{} B".format(int(value) if value.is_integer() else value)
    return "{:.{p}f} {}".format(value, units[index], p=decimal_places)

def format_time(seconds, *, precision=2):
    if isinstance(seconds, bool) or not isinstance(seconds, (int, float)):
        raise TypeError("seconds must be an int or float")
    if seconds < 0:
        raise ValueError("seconds must be non-negative")
    if isinstance(precision, bool) or not isinstance(precision, int) or not 0 <= precision <= 6:
        raise ValueError("precision must be an integer from 0 to 6")
    if seconds < 60:
        return ("{:.%df}s" % precision).format(float(seconds))
    total = int(seconds)
    hours, rem = divmod(total, 3600)
    minutes, secs = divmod(rem, 60)
    parts = []
    if hours: parts.append("{}h".format(hours))
    if minutes: parts.append("{}m".format(minutes))
    if secs or not parts: parts.append("{}s".format(secs))
    return " ".join(parts)

def slugify(value, *, separator="-", lowercase=True, max_length=None):
    if not isinstance(value, str):
        raise TypeError("value must be a string")
    if not isinstance(separator, str) or not separator:
        raise ValueError("separator must be a non-empty string")
    if max_length is not None and (isinstance(max_length, bool) or not isinstance(max_length, int) or max_length < 0):
        raise ValueError("max_length must be a non-negative integer or None")
    text = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    text = re.sub(r"[^A-Za-z0-9]+", separator, text).strip(separator)
    if lowercase: text = text.lower()
    return text[:max_length].rstrip(separator) if max_length is not None else text
